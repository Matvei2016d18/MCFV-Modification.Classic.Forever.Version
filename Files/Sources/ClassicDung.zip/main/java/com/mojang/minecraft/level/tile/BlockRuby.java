package com.mojang.minecraft.level.tile;

public class BlockRuby extends Block {
    
    public BlockRuby(int id, int tex) {
        super(id, tex);
    }
}