package com.mojang.minecraft.gui;

import com.mojang.minecraft.SessionData;
import com.mojang.minecraft.gui.GuiScreen;
import com.mojang.minecraft.level.tile.Block;
import com.mojang.minecraft.render.ShapeRenderer;
import com.mojang.minecraft.render.TextureManager;
import org.lwjgl.opengl.GL11;
import org.lwjgl.input.Mouse;

public final class BlockSelectScreen extends GuiScreen {

   private int cols = 9;
   private int rows;
   private int scrollOffset = 0;
   private int maxScrollOffset;
   private int lastMouseY;

   public BlockSelectScreen() {
      this.grabsMouse = true;
   }

   private int getBlockOnScreen(int var1, int var2) {
      for(int var3 = 0; var3 < SessionData.allowedBlocks.size(); ++var3) {
         int row = var3 / this.cols;
         int col = var3 % this.cols;
         int var4 = this.width / 2 + col * 24 + -108 - 3;
         int var5 = this.height / 2 + (row - this.scrollOffset) * 24 + -60 + 3;
         if(var1 >= var4 && var1 <= var4 + 24 && var2 >= var5 - 12 && var2 <= var5 + 12) {
            return var3;
         }
      }
      return -1;
   }

   private void calculateGrid() {
      int totalBlocks = SessionData.allowedBlocks.size();
      this.cols = 9;
      this.rows = (int) Math.ceil((double) totalBlocks / (double) this.cols);
      
      int visibleRows = Math.min(this.rows, 6);
      this.maxScrollOffset = Math.max(0, this.rows - visibleRows);
      
      if (this.scrollOffset > this.maxScrollOffset) {
         this.scrollOffset = this.maxScrollOffset;
      }
      if (this.scrollOffset < 0) {
         this.scrollOffset = 0;
      }
   }

   public final void render(int var1, int var2) {
      this.calculateGrid();
      
      int totalBlocks = SessionData.allowedBlocks.size();
      int visibleRows = Math.min(this.rows, 6);
      int windowHeight = 30 + visibleRows * 24 + 30;
      
      int mouseScroll = Mouse.getDWheel();
      if (mouseScroll != 0) {
         this.scrollOffset -= mouseScroll / 120;
         if (this.scrollOffset > this.maxScrollOffset) {
            this.scrollOffset = this.maxScrollOffset;
         }
         if (this.scrollOffset < 0) {
            this.scrollOffset = 0;
         }
      }
      
      var1 = this.getBlockOnScreen(var1, var2);
      drawFadingBox(this.width / 2 - 120, 30, this.width / 2 + 120, windowHeight + 30, -1878719232, -1070583712);
      
      if(var1 >= 0) {
         int row = var1 / this.cols;
         int col = var1 % this.cols;
         var2 = this.width / 2 + col * 24 + -108;
         int var3 = this.height / 2 + (row - this.scrollOffset) * 24 + -60;
         drawFadingBox(var2 - 3, var3 - 8, var2 + 23, var3 + 24 - 6, -1862270977, -1056964609);
      }

      drawCenteredString(this.fontRenderer, "Select block (scroll to browse)", this.width / 2, 40, 16777215);
      
      TextureManager var7 = this.minecraft.textureManager;
      ShapeRenderer var8 = ShapeRenderer.instance;
      var2 = var7.load("/terrain.png");
      GL11.glBindTexture(3553, var2);

      for(var2 = 0; var2 < totalBlocks; ++var2) {
         Block var4 = (Block)SessionData.allowedBlocks.get(var2);
         int row = var2 / this.cols;
         int col = var2 % this.cols;
         int screenRow = row - this.scrollOffset;
         
         if (screenRow >= 0 && screenRow < visibleRows) {
            GL11.glPushMatrix();
            int var5 = this.width / 2 + col * 24 + -108;
            int var6 = this.height / 2 + screenRow * 24 + -60;
            GL11.glTranslatef((float)var5, (float)var6, 0.0F);
            GL11.glScalef(10.0F, 10.0F, 10.0F);
            GL11.glTranslatef(1.0F, 0.5F, 8.0F);
            GL11.glRotatef(-30.0F, 1.0F, 0.0F, 0.0F);
            GL11.glRotatef(45.0F, 0.0F, 1.0F, 0.0F);
            if(var1 == var2) {
               GL11.glScalef(1.6F, 1.6F, 1.6F);
            }
            GL11.glTranslatef(-1.5F, 0.5F, 0.5F);
            GL11.glScalef(-1.0F, -1.0F, -1.0F);
            var8.begin();
            var4.renderFullbright(var8);
            var8.end();
            GL11.glPopMatrix();
         }
      }
   }

   protected final void onMouseClick(int var1, int var2, int var3) {
      if(var3 == 0) {
         int blockIndex = this.getBlockOnScreen(var1, var2);
         if (blockIndex >= 0) {
            this.minecraft.player.inventory.replaceSlot(blockIndex);
            this.minecraft.setCurrentScreen((GuiScreen)null);
         }
      }
   }
}