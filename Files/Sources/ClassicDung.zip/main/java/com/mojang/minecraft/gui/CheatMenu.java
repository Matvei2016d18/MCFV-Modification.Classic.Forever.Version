package com.mojang.minecraft.gui;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import com.mojang.minecraft.Minecraft;
import com.mojang.minecraft.player.Player;
import com.mojang.minecraft.gamemode.SurvivalGameMode;
import com.mojang.minecraft.gamemode.CreativeGameMode;
public class CheatMenu extends JFrame {
    
    private Minecraft mc;
    private boolean speedHack = false;
    private boolean jumpHack = false;
    
    public CheatMenu(Minecraft minecraft) {
        this.mc = minecraft;
        
        setTitle("Cassic Dung - Cheats menu (TEST!)");
        setSize(300, 200);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setResizable(false);
        
        JPanel panel = new JPanel();
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
        panel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        
        JLabel label = new JLabel("Enter cheat ID (0-2):");
        label.setAlignmentX(Component.CENTER_ALIGNMENT);
        panel.add(label);
        
        panel.add(Box.createRigidArea(new Dimension(0, 10)));
        
        JTextField input = new JTextField();
        input.setHorizontalAlignment(JTextField.CENTER);
        panel.add(input);
        
        panel.add(Box.createRigidArea(new Dimension(0, 10)));
        
        JButton enterButton = new JButton("Activate");
        enterButton.setAlignmentX(Component.CENTER_ALIGNMENT);
        panel.add(enterButton);
        
        JLabel status = new JLabel("Status: No cheats");
        status.setAlignmentX(Component.CENTER_ALIGNMENT);
        status.setForeground(Color.RED);
        panel.add(Box.createRigidArea(new Dimension(0, 10)));
        panel.add(status);
        
        enterButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String text = input.getText().trim();
                applyCheat(text);
                status.setText("Cheat " + text + " applied");
                status.setForeground(Color.GREEN);
                input.setText("");
            }
        });
        
        input.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                enterButton.doClick();
            }
        });
        
        add(panel);
        setVisible(true);
    }
    
    private void applyCheat(String id) {
        if(id.equals("0")) {
            mc.cheatCommand = "";
            JOptionPane.showMessageDialog(null, "All cheats disabled!", "Cheat Menu", JOptionPane.INFORMATION_MESSAGE);
        }
		else {
			mc.cheatCommand = id;
            JOptionPane.showMessageDialog(null, "Cheat " + id + " applied!", "Cheat Menu", JOptionPane.INFORMATION_MESSAGE);
        }
    }
}