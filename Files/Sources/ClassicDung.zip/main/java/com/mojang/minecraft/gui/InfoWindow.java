package com.mojang.minecraft.gui;

import javax.swing.*;
import java.awt.*;

public class InfoWindow extends JFrame {
    
    public InfoWindow() {
        setTitle("PMLFOV - Client Info");
        setSize(350, 250);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setResizable(false);
        
        JPanel panel = new JPanel();
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
        panel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        
        // Information
        String info = 
            "=== PMLFOV Client Info ===\n\n" +
            "Version: Minecraft Classic 0.30\n" +
            "Engine: MCFV (Minecraft Classic Forever)\n" +
            "Renderer: LWJGL 2.9.0\n" +
            "Java: " + System.getProperty("java.version") + "\n" +
            "OS: " + System.getProperty("os.name") + "\n" +
            "Memory: " + (Runtime.getRuntime().maxMemory() / 1024 / 1024) + " MB max\n\n" +
            "=== Mods ===\n" +
            "- Water/Lava in inventory\n" +
            "- Scrollable block menu\n" +
            "- Info window (you are here!)";
        
        JTextArea textArea = new JTextArea(info);
        textArea.setEditable(false);
        textArea.setBackground(new Color(0, 0, 0, 0));
        textArea.setFont(new Font("Monospaced", Font.PLAIN, 12));
        
        JScrollPane scrollPane = new JScrollPane(textArea);
        
        JButton closeButton = new JButton("Close");
        closeButton.addActionListener(e -> dispose());
        
        panel.add(scrollPane);
        panel.add(Box.createRigidArea(new Dimension(0, 10)));
        panel.add(closeButton);
        
        add(panel);
        setVisible(true);
    }
}