package com.mojang.minecraft.mob;

import com.mojang.minecraft.Entity;
import com.mojang.minecraft.level.Level;
import com.mojang.minecraft.mob.QuadrupedMob;
import com.mojang.minecraft.mob.ai.JumpAttackAI;
import com.mojang.minecraft.level.tile.Block;
import com.mojang.minecraft.item.Arrow;
import com.mojang.minecraft.item.Item;

public class Spider extends QuadrupedMob {

   public static final long serialVersionUID = 0L;

   public Spider(Level var1, float var2, float var3, float var4) {
      super(var1, var2, var3, var4);
      this.heightOffset = 0.72F;
      this.modelName = "spider";
      this.textureName = "/mob/spider.png";
      this.setSize(1.4F, 0.9F);
      this.setPos(var2, var3, var4);
      this.deathScore = 25;
      this.bobStrength = 0.0F;
      this.ai = new JumpAttackAI();
   }
   // if spider die create tnt
   public void die(Entity var1) {
      super.die(var1);
      this.level.addEntity(new Item(this.level, this.x, this.y, this.z, Block.TNT.id));
   }
	public void aiStep() {
		super.aiStep();
    
		if (this.onWall()) {
			this.yd = 0.0F;
        
			if (this.xd != 0.0F || this.zd != 0.0F) {
				this.yd = 0.5F;
			} else {
				this.yd = 0.0F;
			}
		}
	}

	private boolean onWall() {
		int x = (int)Math.floor(this.x);
		int y = (int)Math.floor(this.y);
		int z = (int)Math.floor(this.z);
    
		return level.isSolidTile(x + 1, y, z) ||
			level.isSolidTile(x - 1, y, z) ||
			level.isSolidTile(x, y, z + 1) ||
			level.isSolidTile(x, y, z - 1);
	}
}