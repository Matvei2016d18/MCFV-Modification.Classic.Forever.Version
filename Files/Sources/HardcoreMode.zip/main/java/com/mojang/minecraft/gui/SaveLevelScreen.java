package com.mojang.minecraft.gui;

import com.mojang.minecraft.gui.Button;
import com.mojang.minecraft.gui.GuiScreen;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import java.io.File;
import com.mojang.minecraft.gui.LevelDialog;

public final class SaveLevelScreen extends GuiScreen {

   private GuiScreen parent;

   public SaveLevelScreen(GuiScreen var1) {
      this.parent = var1;
   }

   public final void onOpen() {
      this.buttons.clear();
      this.buttons.add(new Button(0, this.width / 2 - 100, this.height / 4, "Save to level.dat"));
      this.buttons.add(new Button(1, this.width / 2 - 100, this.height / 4 + 24, "Save as... (choose location)"));
      this.buttons.add(new Button(2, this.width / 2 - 100, this.height / 4 + 48, "Back"));
   }

   protected final void onButtonClick(Button var1) {
      if(var1.id == 0) {
          try {
              this.minecraft.levelIo.save(this.minecraft.level, new File("level.mine"));
              System.out.println("World saved to level.mine");
          } catch(Exception e) {
              e.printStackTrace();
              JOptionPane.showMessageDialog(null, "Failed to save world!", "Error", JOptionPane.ERROR_MESSAGE);
          }
      } else if(var1.id == 1) {
          new Thread(() -> {
              JFileChooser chooser = new JFileChooser();
              chooser.setDialogTitle("Save Minecraft World");
              chooser.setSelectedFile(new File("level.mine"));
              int result = chooser.showSaveDialog(null);
              if(result == JFileChooser.APPROVE_OPTION) {
                  File file = chooser.getSelectedFile();
                  try {
                      this.minecraft.levelIo.save(this.minecraft.level, file);
                      System.out.println("World saved to " + file.getAbsolutePath());
                      JOptionPane.showMessageDialog(null, "World saved to " + file.getName(), "Saved", JOptionPane.INFORMATION_MESSAGE);
                  } catch(Exception e) {
                      e.printStackTrace();
                      JOptionPane.showMessageDialog(null, "Failed to save world!", "Error", JOptionPane.ERROR_MESSAGE);
                  }
              }
          }).start();
      } else if(var1.id == 2) {
          this.minecraft.setCurrentScreen(this.parent);
      }
   }

   public final void render(int var1, int var2) {
      drawFadingBox(0, 0, this.width, this.height, 1610941696, -1607454624);
      drawCenteredString(this.fontRenderer, "Save level", this.width / 2, 40, 16777215);
      super.render(var1, var2);
   }
}