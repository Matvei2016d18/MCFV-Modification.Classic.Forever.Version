package com.mojang.minecraft.mob;

import com.mojang.minecraft.Entity;
import com.mojang.minecraft.level.Level;
import com.mojang.minecraft.mob.QuadrupedMob;
import com.mojang.minecraft.mob.ai.JumpAttackAI;
import com.mojang.minecraft.level.tile.Block;
import com.mojang.minecraft.player.Player;
import com.mojang.minecraft.item.Arrow;

public class Spider extends QuadrupedMob {

   public static final long serialVersionUID = 0L;

   public Spider(Level var1, float var2, float var3, float var4) {
      super(var1, var2, var3, var4);
      this.heightOffset = 0.72F;
      this.modelName = "spider";
      this.textureName = "/mob/spider.png";
      this.setSize(1.4F, 0.9F);
      this.setPos(var2, var3, var4);
      this.deathScore = 105;
      this.bobStrength = 0.0F;
      this.ai = new JumpAttackAI();
   }
   // if spider die add tnt to inventory
   public void die(Entity var1) {
      super.die(var1);
      if(var1 instanceof Player) {
          Player player = (Player)var1;
          player.inventory.slots[8] = Block.TNT.id;
          player.inventory.count[8] += 7;
      }
      else if(var1 instanceof Arrow) {
          Player player = (Player)this.level.getPlayer();
          if(player != null) {
              player.inventory.slots[8] = Block.TNT.id;
              player.inventory.count[8] += 7;
          }
      }
   }
}